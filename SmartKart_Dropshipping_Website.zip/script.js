// ====== IMPORTANT: नीचे अपना WhatsApp नंबर बदलें ======
// भारत के नंबर के लिए 91 के बाद 10 अंकों का नंबर लिखें, + या spaces न लगाएँ।
const WHATSAPP_NUMBER = "919691362649";

const products = [
  {id:1,name:"Rechargeable LED Light",category:"lighting",tag:"LIGHTING",price:399,emoji:"🔦",desc:"घर और यात्रा के लिए उपयोगी लाइट।"},
  {id:2,name:"Bluetooth Speaker",category:"smart",tag:"SMART GADGET",price:599,emoji:"🔊",desc:"कॉम्पैक्ट वायरलेस स्पीकर।"},
  {id:3,name:"Mobile Stand",category:"mobile",tag:"MOBILE ACCESSORY",price:199,emoji:"📱",desc:"वीडियो देखने और डेस्क उपयोग के लिए।"},
  {id:4,name:"USB Mini Fan",category:"smart",tag:"SMART GADGET",price:299,emoji:"🌀",desc:"छोटा और पोर्टेबल फैन।"},
  {id:5,name:"Motion Sensor Light",category:"lighting",tag:"LIGHTING",price:349,emoji:"💡",desc:"कैबिनेट और रास्तों के लिए सेंसर लाइट।"},
  {id:6,name:"Fast Charging Cable",category:"mobile",tag:"MOBILE ACCESSORY",price:149,emoji:"🔌",desc:"मोबाइल चार्जिंग के लिए केबल।"},
  {id:7,name:"Wireless Earbuds",category:"smart",tag:"SMART GADGET",price:799,emoji:"🎧",desc:"रोज़मर्रा के उपयोग के लिए ईयरबड्स।"},
  {id:8,name:"Phone Holder",category:"mobile",tag:"MOBILE ACCESSORY",price:249,emoji:"📲",desc:"डेस्क या वीडियो कॉल के लिए होल्डर।"}
];

let cart = [];
const money = n => "₹" + n.toLocaleString("en-IN");
const grid = document.getElementById("productGrid");

function renderProducts(filter="all"){
  grid.innerHTML = products.filter(p=>filter==="all"||p.category===filter).map(p=>`
    <article class="product-card">
      <div class="product-art">${p.emoji}</div>
      <div class="product-info">
        <span class="tag">${p.tag}</span><h3>${p.name}</h3>
        <p class="product-desc">${p.desc}</p>
        <div class="price-row"><span class="price">${money(p.price)}</span>
        <button class="add-button" onclick="addToCart(${p.id})">+ कार्ट</button></div>
      </div>
    </article>`).join("");
}
function addToCart(id){
  const item=cart.find(x=>x.id===id);
  if(item)item.qty++;else cart.push({id,qty:1});
  updateCart();
}
function changeQty(id,delta){
  const item=cart.find(x=>x.id===id);if(!item)return;
  item.qty+=delta;if(item.qty<=0)cart=cart.filter(x=>x.id!==id);
  updateCart();
}
function updateCart(){
  const count=cart.reduce((s,x)=>s+x.qty,0);
  const total=cart.reduce((s,x)=>s+x.qty*products.find(p=>p.id===x.id).price,0);
  document.getElementById("cartCount").textContent=count;
  document.getElementById("cartTotal").textContent=money(total);
  const box=document.getElementById("cartItems");
  box.innerHTML=cart.length?cart.map(x=>{
    const p=products.find(y=>y.id===x.id);
    return `<div class="cart-item"><div><strong>${p.name}</strong><small>${money(p.price)} × ${x.qty}</small></div>
    <div class="qty-controls"><button onclick="changeQty(${p.id},-1)">−</button><b>${x.qty}</b><button onclick="changeQty(${p.id},1)">+</button></div></div>`;
  }).join(""):`<p class="empty-cart">आपका कार्ट अभी खाली है।</p>`;
}
function openCart(){document.getElementById("cartDrawer").classList.add("open");document.getElementById("overlay").classList.add("show")}
function closeCart(){document.getElementById("cartDrawer").classList.remove("open");document.getElementById("overlay").classList.remove("show")}
function sendWhatsApp(message){
  if(!/^91\d{10}$/.test(WHATSAPP_NUMBER)){alert("पहले script.js में अपना 10 अंकों का WhatsApp नंबर सेट करें।");return;}
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`,"_blank");
}
document.getElementById("openCart").addEventListener("click",openCart);
document.getElementById("closeCart").addEventListener("click",closeCart);
document.getElementById("overlay").addEventListener("click",closeCart);
document.getElementById("checkoutButton").addEventListener("click",()=>{
  if(!cart.length){alert("पहले कार्ट में प्रोडक्ट जोड़ें।");return;}
  const lines=cart.map(x=>{const p=products.find(y=>y.id===x.id);return `${p.name} — ${x.qty} × ${money(p.price)} = ${money(x.qty*p.price)}`;});
  const total=cart.reduce((s,x)=>s+x.qty*products.find(p=>p.id===x.id).price,0);
  sendWhatsApp("नमस्ते SmartKart! मैं ये प्रोडक्ट ऑर्डर करना चाहता/चाहती हूँ:\n\n"+lines.join("\n")+"\n\nकुल (डिलीवरी से पहले): "+money(total)+"\n\nकृपया उपलब्धता, डिलीवरी चार्ज और अंतिम राशि बताएं।");
});
document.getElementById("contactWhatsApp").addEventListener("click",e=>{e.preventDefault();sendWhatsApp("नमस्ते SmartKart, मुझे जानकारी चाहिए।");});
document.querySelectorAll(".filter").forEach(btn=>btn.addEventListener("click",()=>{
  document.querySelectorAll(".filter").forEach(b=>b.classList.remove("active"));
  btn.classList.add("active");renderProducts(btn.dataset.filter);
}));
document.getElementById("year").textContent=new Date().getFullYear();
renderProducts();

# SmartKart Dropshipping Website

यह एक responsive static storefront है। इसमें:
- मोबाइल और डेस्कटॉप लेआउट
- प्रोडक्ट कैटेगरी फ़िल्टर
- कार्ट और quantity controls
- WhatsApp पर ऑर्डर सारांश भेजने की सुविधा
- नीतियों का शुरुआती पेज

## लॉन्च से पहले जरूरी बदलाव
1. `script.js` में `WHATSAPP_NUMBER = "91XXXXXXXXXX"` को अपने WhatsApp नंबर से बदलें।
2. `products` सूची में demo products, कीमतें, नाम, विवरण और emoji को वास्तविक DeoDap प्रोडक्ट जानकारी से बदलें।
3. वेबसाइट का नाम `SmartKart` बदलना हो तो `index.html`, `policies.html` और README में बदलें।
4. सप्लायर से लिखित में पुष्टि करें कि वह आपके ब्रांड/ग्राहक के पते पर blind shipping, tracking, COD (यदि चाहिए), returns और नुकसान/रिफंड कैसे संभालता है।
5. वास्तविक product photos केवल अनुमति/लाइसेंस के साथ इस्तेमाल करें।
6. `policies.html` में वास्तविक संपर्क विवरण, शिपिंग, रिटर्न, रिफंड और गोपनीयता नीति पूरी करें।

## मुफ्त में GitHub Pages पर प्रकाशित करना
1. GitHub पर नया public repository बनाएँ, जैसे `smartkart-store`.
2. इस ZIP की सभी फाइलें repository के root में upload करें।
3. Repository में Settings → Pages खोलें।
4. Build and deployment में Deploy from a branch चुनें।
5. Branch `main` और folder `/ (root)` चुनकर Save करें।
6. प्रकाशित होने के बाद GitHub Pages URL खुलेगा।

## सीमाएँ
यह front-end starter है, पूरा backend e-commerce system नहीं। यह खुद से payment collect नहीं करता, stock sync नहीं करता, DeoDap API से connect नहीं है, automatic order forwarding/tracking नहीं करता और customer database नहीं रखता। WhatsApp order handoff के बाद order को manually supplier portal में place करना होगा। COD/online payment शुरू करने से पहले payment provider, tax, consumer policy और supplier process जाँचें।
